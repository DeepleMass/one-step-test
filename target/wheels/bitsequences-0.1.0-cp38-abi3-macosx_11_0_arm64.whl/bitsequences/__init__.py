from .bitsequences import *

__doc__ = bitsequences.__doc__
if hasattr(bitsequences, "__all__"):
    __all__ = bitsequences.__all__